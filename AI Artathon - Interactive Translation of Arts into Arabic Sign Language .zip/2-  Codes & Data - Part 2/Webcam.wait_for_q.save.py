# Webcam.wait_for_q.save.py

import cv2
import os   # to detect the Operating system with os.name() method


os_name = os.name

print(f'{os_name = }')

if os_name == 'posix':   # unix, including MacOS
    cap = cv2.VideoCapture(0)
elif os_name == 'nt':   # Windows
    cap = cv2.VideoCapture(1)

print(f'{cap = }')

# ret, frame = cap.read()


# image_filename = 'capture.jpg'
# print(f'cv2.imwrite({image_filename}, frame)', flush=True)

# cv2.imwrite(image_filename, frame)

print("Live.  Hit 'q' to capture image.")
      
while(True):
    ret, frame = cap.read()
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA)

    # cv2.imshow('frame', rgb)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        out = cv2.imwrite('capture_q.jpg', frame)
        break

cap.release()
cv2.destroyAllWindows()