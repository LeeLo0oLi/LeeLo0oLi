# Webcam.no_wait.py

import cv2   # OpenCV
import time   # for pausing with time.sleep(n_seconds)
import sys   # for exception handling
import os   # to detect the Operating system with os.name() method


try:
    print('turning on Webcam')
    # intialize a VideoCapture object from the Webcam (0)
    '''
    Speak the input text.
    Works on Windows and unix machines (such as MacOS).
    '''
    os_name = os.name

    if os_name == 'posix':   # unix, including MacOS
        cap = cv2.VideoCapture(0)
    elif os_name == 'nt':   # Windows
        cap = cv2.VideoCapture(1)


    # if the camera initialization fails, OpenCV does NOT raise an exception --> very bad,
    # since the code interpretation simply continues!
    # Instead you get some printed message [sif i tried cv2.VideoCapture(1)]:
    # OpenCV: out device of bound (0-0): 1
    # OpenCV: camera failed to properly initialize!
    print(f'{cap = }')
    print('Webcam on, pausing for 1.5 seconds')
    time.sleep(1.5)
    
    # while True:
    # get image from the WebCam
    ret, frame = cap.read()

    print(f'{ret = }')   # True (if read from Webcam worked properly)
    # print(f'{type(ret) = }')   # <class 'bool'>
    print('-'*50)

    # print(f'{frame = }')
    print(f'{type(frame) = }')   # <class 'numpy.ndarray'>
    print(f'{frame.ndim = }')   # 3
    print(f'{frame.shape = }')   # (720, 1280, 3) on Ed's MacBook Air

    # cv2.imshow('frame', frame)

    # 3 channels (R, G, B)
    image_filename = 'captured_image.jpg'
    print(f'cv2.imwrite({image_filename}, frame)', flush=True)
    cv2.imwrite(image_filename, frame)
    print(f'{frame[1][1][:] = }')

    # 4 channels (R, G, B, 255)
    image_filename_rgb = 'captured_image.rgb.jpg'
    print(f'cv2.imwrite({image_filename_rgb}, frame)', flush=True)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA)
    cv2.imwrite(image_filename_rgb, rgb)
    print(f'{rgb[1][1][:] = }')
    # cv2.imshow('frame', rgb)

    # gray scale)
    image_filename_gray = 'captured_image.gray.jpg'
    # image = cv2.imread('C:/Users/N/Desktop/Test.jpg')
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # cv2.imshow('Original image', frame)
    cv2.imwrite(image_filename_gray, gray)
    # cv2.imshow('Gray image', gray)
    # print(f'{gray[1][1][:] = }')  # "Oops! <class 'IndexError'> occurred." from exception handling
    
    # Delay before the next read ... especially if you are writing files.
    # If writing files ... will also want to limit this with a loop for N # of files or
    #    until user escapes the capture sequence

    # time.sleep(1)

    # if cv2.waitKey(1) & 0xFF == ord('q'):   # Cannot get this to work in Jupyter Notebook
    #     break
    # break   # only do one image
except:
    print("Oops!", sys.exc_info()[0], "occurred.")


# Webcam will stay on unless you release it
print('releasing Webcam')
cap.release()

print('destroyAllWindows()')
cv2.destroyAllWindows()

print('Done')