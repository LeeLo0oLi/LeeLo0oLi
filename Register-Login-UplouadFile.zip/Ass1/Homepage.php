<style>
 html {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
  body {
  margin: 3% auto auto 30%;
  padding: 0%;
  font-family: "Poppins", "Arial", "Helvetica Neue", sans-serif;
  font-weight: 400;
  font-size: 14px;
}
.card-body {
  padding-bottom: 65px;
  display: table-cell;
  display: block;
  width: 100%;
  padding: 37px 30px;
  padding-bottom: 45px;
}

.card-3 {
  background: #000;
  -webkit-border-radius: 10px;
  -moz-border-radius: 10px;
  border-radius: 10px;
  -webkit-box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  display: table;
  background: url("144484.jpg") top left/cover no-repeat;
  display: table-cell;
  background-position: center center;
  display: block;
  width: 50%;
  padding: 0px;
  margin: 0px;
}
a{
    background-color: #FFF
}
</style>

<?php
// Connection with DB
session_start();
$conn=mysqli_connect('localhost','root','', 'hw1');

if(!$conn){

echo "not connected";
} 
// User Login by session

if (isset($_GET['logout'])) {
  unset($_SESSION['uname']);
} 
?>

<!-- User Data Form -->
<!DOCTYPE html>
<html>
    <html>
    <title>Home</title>
    </html>
    <body>
     <div class="card card-3">
        <div class="card-body">
            <div>
          <!-- Remumber user who is loging in -->
          <?php
            if (isset($_SESSION['uname'])) {
                $get_current_user = mysqli_query($conn, "SELECT * FROM users where 
                                                          uname='{$_SESSION['uname']}'");
                  $row = mysqli_fetch_assoc($get_current_user); 
         ?> 
         <!-- User Name -->
         <h3> Welcome dear : <?php echo $row['uname']; ?>  </h3>
         <br> 
         <h5 style="color:skyblue;"> Check Your Photo :)  </h5>
         <br>
         <figure><img src="images/<?php echo $row['image']; ?>"
                      width="350px" alt="Your Image"></figure>         
        </div>
        <?php } ?>
        </div>
       </div> 
    </body>
</html>