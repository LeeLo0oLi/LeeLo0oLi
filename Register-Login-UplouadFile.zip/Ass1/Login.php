<style>
 html {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
  body {
  margin: 3% auto auto 30%;
  padding: 0%;
  font-family: "Poppins", "Arial", "Helvetica Neue", sans-serif;
  font-weight: 400;
  font-size: 14px;
}
.card-body {
  padding-bottom: 65px;
  display: table-cell;
  display: block;
  width: 100%;
  padding: 37px 30px;
  padding-bottom: 45px;
}

.card-3 {
  background: #000;
  -webkit-border-radius: 10px;
  -moz-border-radius: 10px;
  border-radius: 10px;
  -webkit-box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  display: table;
  background: url("144484.jpg") top left/cover no-repeat;
  display: table-cell;
  background-position: center center;
  display: block;
  width: 50%;
  padding: 0px;
  margin: 0px;
}
a{
    background-color: #FFF
}
</style>

<?php
// Connection with DB
session_start();
$conn=mysqli_connect('localhost','root','', 'hw1');

if(!$conn){

echo "not connected";
} 
// User Login/Registration
if (isset($_POST['login'])) {
    
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];

    $login = mysqli_query($conn, "SELECT * FROM users where uname='$uname' or pass='$pass'");
    $user_data = mysqli_fetch_assoc($login);

    if ($user_data['pass'] != $pass && $uname == $user_data['uname']) {
        echo "Incorrect Password, Please Try Again!";
    } 
    else {
        if (mysqli_num_rows($login) > 0) {
            $_SESSION['uname'] = $user_data['uname'];
            header('location:Homepage.php');
        } else {
            echo "User is Not Registered, yet!";
        }
    }
}
?>

<!-- User Login Form -->
<!DOCTYPE html>
<html>
    <html>
    <title>LogIn</title>
    </html>
    <body>
     <div class="card card-3">
        <div class="card-body">
            <!-- 
               enctype must be included
                    method post >> hide data
            -->
            <div>
            <form action="Login.php" name='validate' method="POST">
            <!-- User Name -->
            <input type="text" name='uname' placeholder="Username">
            <br><br>
            <!-- User Password -->
            <input type="password" name='pass' placeholder="Password">
            <br><br>
            </div>
            <div>
            <!-- Save Data -->
            <input type="checkbox" name="rememberme"/>
            <label for="rememberme"><span><span></span></span>Remember Me</label>
            <!-- Login -->
            <input type="submit" name="login" value="Login">
            <a href="Register.php"> Not a Member? Register Here </a>
            </div>
            </form>
        </div>
       </div> 
    </body>
</html>