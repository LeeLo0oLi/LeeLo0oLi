<style>
 html {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
  body {
  margin: 3% auto auto 30%;
  padding: 0%;
  font-family: "Poppins", "Arial", "Helvetica Neue", sans-serif;
  font-weight: 400;
  font-size: 14px;
}
.card-body {
  padding-bottom: 65px;
  display: table-cell;
  display: block;
  width: 100%;
  padding: 37px 30px;
  padding-bottom: 45px;
}

.card-3 {
  background: #000;
  -webkit-border-radius: 10px;
  -moz-border-radius: 10px;
  border-radius: 10px;
  -webkit-box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  display: table;
  background: url("144484.jpg") top left/cover no-repeat;
  display: table-cell;
  background-position: center center;
  display: block;
  width: 50%;
  padding: 0px;
  margin: 0px;
}
a{
    background-color: #FFF
}
</style>

<?php
// Connection with DB
$conn=mysqli_connect('localhost','root','', 'hw1');

if(!$conn){

echo "not connected";
} 
// file/image size limit
ini_set('upload_max_filesize', '120M');
ini_set('post_max_size', '120M');

if (isset($_POST['submit'])) {
// Load data on sever 'post method by get input name from the form'
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $job = $_POST['job'];
// Image/File Upload    
    $path = 'images/';
    $image = $_FILES['image']['name'];
    $file = $_FILES['file']['name'];
    $tmp_name1 = $_FILES['image']['tmp_name'];
    $tmp_name2 = $_FILES['file']['tmp_name'];
// Move uploaded files to the path folder in server 
    $Upluded_image = move_uploaded_file($tmp_name1, $path . $image);
    $Upluded_file = move_uploaded_file($tmp_name2, $path . $file);
// Insert data in the table 'users'    
    $new_user = mysqli_query($conn, "INSERT INTO users(uname,pass,age,gender,address,job,image,file)
    VALUES('$uname','$pass','$age','$gender','$address','$job','$image','$file')");
// mysqli_query() function performs a query against a database
$result = mysqli_query($conn, $new_user);
}
?>

<!-- User Registration Form -->
<!DOCTYPE html>
<html>
    <body>
     <div class="card card-3">
        <div class="card-body">
            <!-- 
                method / enctype must be included
                    method post >> hide data
                    enctype >> This will tell the form that I want to take files such as
                                audio/video/images and etc..
            -->
            <form action="Register.php" name='validate' method="POST" enctype="multipart/form-data">
            <!-- User Name -->
            <input type="text" name='uname' placeholder="Username">
            <br><br>
            <!-- User Password -->
            <input type="password" name='pass' placeholder="Password">
            <br><br>
            <!-- User Age -->
            <input type="text" name='age' placeholder="Age">
            <br><br>
            <!-- User Gender -->
            <input type="radio" name="gender" value="Male">Male
            &nbsp; <input type="radio" name="gender" value="Female">Female
            <br><br>
            <!-- User Address -->
            <textarea name="address" rows="4" cols="40" placeholder="Enter text here..."></textarea>
            <br><br>
            <!-- User Job -->
            <select name="job" id='job'>
                <option value="" disabled selected>Please Choose your Job</option>
                <option value="Doctor">Doctor</option>
                <option value="Engineer">Engineer</option>
                <option value="Teacher">Teacher</option>
                <option value="System-Analyst">System Analyst</option>
                <option value="Web-Developer">Web Developer</option>
                <option value="Other">Other</option>
            </select>
            <br><br>
            <!-- Image Upload -->
            <label for="">Upload Image</label>
            <input type="file" name='image'>
            <br><br>
            <!-- File Upload -->
            <label for="">Upload File</label>
            <input type="file" name='file'>
            <br><br>
            <!-- Submit Form -->
            <input type="submit" name="submit" value="Register">
            <a href="Login.php">I'am Already a Member</a>
            </form>
        </div>
       </div> 
    </body>
</html>