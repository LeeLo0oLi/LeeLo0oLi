<?php
// Connection with DB
$conn = mysqli_connect('localhost','root','', 'uinfo') or die('Unable to connect to DB');

$id = $_POST['id'];
$uname = $_POST['uname'];
$pwd = $_POST['pwd'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$bod = $_POST['bod'];
$gender = $_POST['gender'];
?>

<!DOCTYPE html>
<html>
<head>
<title> User Database </title>
</head>
<body>
    <form action="index.php" method="POST">
     <input type="text" name="id" placeholder="ID">
     <br><br>
     <input type="text" name="uname" placeholder="User Name">
     <br><br>
     <input type="password" name="pwd" placeholder="Password">
     <br><br>
     <input type="text" name="phone" placeholder="Phone">
     <br><br>
     <input type="text" name="address" placeholder="Address">
     <br><br>
     Birthday: <input type="date" name="bod">
     <br><br>
     Gender: <input type="radio" name="gender" value="Male" >Male
      &nbsp; <input type="radio" name="gender" value="Female" >Female
    <br><br>
    <button name="search">Search</button>
    <button name="insert">Insert</button>
    <!--<button name="update">Update</button>-->
    <button name="delete">Delete</button>
    </form>
</body>
</html>

<?php
if(isset($_POST['search'])){
    $search = mysqli_query($conn,"SELECT * FROM user WHERE id ='$_POST[id]'");

    if (mysqli_num_rows($search) == 0){ 
        echo "no user found";   } 
    while($row = mysqli_fetch_array($search))
        { echo  "<br>". "User ID: " . $row['id'] ."<br>". "User name: " . $row['uname'] ."<br>". "Phone: " . $row['phone'] . "<br>". "Address: " . $row['address'] . "<br>"."Gender: " . $row['gender'] ."<br>". "BOD: " . $row['bod'] ;} 

}elseif (isset($_POST['insert'])){
    $insert = mysqli_query($conn,"INSERT INTO user (uname, pwd, phone, address, bod, gender )
                        VALUES ('$_POST[uname]','$_POST[pwd]','$_POST[phone]','$_POST[address]','$_POST[bod]' ,'$_POST[gender]')");
    if (mysqli_affected_rows($conn) == 0 ) {
        echo " Error: Nothing was added ";
    } else {  echo "Data was sucessfully added"  ;   }
    
} elseif (isset($_POST['delete'])){
    $delete = mysqli_query($conn,"DELETE FROM user WHERE id='$_POST[id]'");
    if (mysqli_affected_rows($conn) == 0 ) {
        echo " Error: Nothing was deleted ";
    } else {  echo $_POST['id'] . " was sucessfully  deleted"  ;   }

}
/* الكود صح بس ما زبط
elseif (isset($_POST['update'])){
    $id = $_POST['id'];
    $sql= " UPDATE `user` SET 
            uname = '$_POST[uname]', 
            pwd = '$_POST[pwd]', 
            phone = '$_POST[phone]', 
            address = '$_POST[address]', 
            bod = '$_POST[bod]',
            gender = '$_POST[gender]'
            WHERE id = '$_POST[id]'";
    if ($update = mysqli_query($conn,$sql)) {
        echo " Error: Nothing was updated ";
    } else {  echo "Data was sucessfully updated" ;
              header( "refresh:2, url=index.php") ;   } 
}*/
mysqli_close($conn);
?>